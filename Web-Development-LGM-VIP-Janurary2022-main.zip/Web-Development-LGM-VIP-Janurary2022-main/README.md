# Web-Development-LGM-VIP-Janurary2022
This repository contains the projects that created under _**Lets Grow More Virtual Internship Program**_.

There are tow projects named as **Task_1** and **Task_2**.

## Task_1: __*Create a single page website*__.

In the task 1 I have to create a single page website, that have the section like Header, Home, About, Projects, Pricing, Videos, Team, Contact and Footer.

**Web Technologies Used**:
* HTML
* CSS &
* JavaScript

**Video Link**: https://www.youtube.com/watch?v=CLwZDVP8g38


## Task_2: __*Create a web application using create-react-app*__

In the task 2 I have to create a web app and there add a get user button on the navbar, which makes an api call to get the user data.

**Web Technologies Used**:
* ReactJS &
* CSS

**Video Link**: https://www.youtube.com/watch?v=tZPyh4QW5A8
